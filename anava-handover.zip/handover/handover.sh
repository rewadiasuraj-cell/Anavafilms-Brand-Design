#!/usr/bin/env bash
# Put the page generator and its data into the redesign-2026 branch so a
# future session can rebuild the pages instead of hand-editing them.
set -euo pipefail
BD=https://github.com/rewadiasuraj-cell/Anavafilms-Brand-Design.git
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/.ho"
rm -rf "$WORK"; mkdir -p "$WORK"; cd "$WORK"
git clone --depth 1 --branch redesign-2026 "$BD" bd
cd bd
cp "$HERE/build_anava.py" "$HERE/work.json" "$HERE/BUILD.md" .
if git diff --quiet && [ -z "$(git status --porcelain)" ]; then
  echo "Already up to date."; exit 0
fi
git add -A && git status --short
git commit -m "Add the page generator, its card data and build notes"
git push origin redesign-2026
echo
echo "Done. build_anava.py, work.json and BUILD.md are on redesign-2026."
