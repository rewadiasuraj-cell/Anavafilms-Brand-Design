# ANAVA FILMS — redesign, ready to deploy

## Quickest route

    unzip anava-deploy.zip
    cd handoff
    ./push.sh

The script clones both repos, assembles the site, checks Cloudflare's
25 MiB per-file limit, commits to a new branch `redesign-2026` and pushes.
It never touches `main`, so anavafilms.com's current site is unaffected.

You'll need a GitHub personal access token when it pushes:
github.com/settings/personal-access-tokens/new — select only the
`Anavafilms-Brand-Design` repo, permission `Contents: Read and write`.

## What's in here

    index.html work.html what-we-do.html process.html about.html contact.html
    assets/css/anava.css          one stylesheet
    assets/js/anava.js            one script
    assets/...                    47 assets made or re-encoded for this redesign
    assets-from-anava-films.txt   166 media files pulled from the live-site repo
    build_anava.py                generates all 6 pages
    work.json                     83 work cards
    push.sh                       does everything above

## If you change the design later

Don't edit the HTML by hand — it's generated. Edit `build_anava.py`, then:

    python3 build_anava.py

CSS and JS are edited directly.

## Things worth knowing

- Internal links are extensionless (`work`, not `work.html`). On Hostinger
  `.htaccess` handles that; Cloudflare Workers static assets do too.
- `aqua-color-1.mp4` and `aqua-color-2.mp4` ship re-encoded (35 MB and 32 MB
  originals exceeded Cloudflare's 25 MiB limit; now 3.5 MB and 4.2 MB).
- Video playback could not be verified in the build environment — check
  hover-play and the lightbox on the preview before going live.

## Going live on Hostinger, once the preview looks right

hPanel -> File Manager -> `public_html`:

1. Zip `public_html` first, as a rollback.
2. Upload the 6 HTML files, `assets/css/anava.css`, `assets/js/anava.js`.
3. Upload the new assets: `assets/images/thumbnails/`, `assets/Companies logo/`,
   `assets/images/posters/bts-*`, and the BTS clips.
4. Leave `.htaccess` alone.
5. Hard refresh.
