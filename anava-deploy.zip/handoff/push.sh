#!/usr/bin/env bash
# ANAVA FILMS redesign -> Cloudflare preview branch.
# Works with plain bash on macOS/Linux and with Git Bash on Windows.
# Only git is required.
set -euo pipefail

BD=https://github.com/rewadiasuraj-cell/Anavafilms-Brand-Design.git
AF=https://github.com/rewadiasuraj-cell/Anava-Films.git
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/.deploy"

command -v git >/dev/null || { echo "git is not installed. Install it first."; exit 1; }

rm -rf "$WORK"; mkdir -p "$WORK"; cd "$WORK"
echo "==> Cloning both repos (~1.4 GB, give it a few minutes)"
git clone "$BD" bd
git clone --depth 1 "$AF" af

cd bd
git checkout -b redesign-2026

echo "==> Copying the redesign (6 pages, CSS, JS, 47 made-for-this assets)"
# cp rather than rsync: rsync is missing from Git Bash on Windows.
for f in index.html work.html what-we-do.html process.html about.html contact.html; do
  cp "$HERE/$f" .
done
cp -R "$HERE/assets/." ./assets/

echo "==> Copying the remaining media from Anava-Films at identical paths"
# Copying beats renaming: two Lenskart testimonials are swapped between the
# repos, so matching by filename puts the wrong video on the wrong card.
n=0
while IFS= read -r p; do
  [ -z "$p" ] && continue
  mkdir -p "$(dirname "$p")"
  cp "$WORK/af/$p" "$p"
  n=$((n+1))
done < "$HERE/assets-from-anava-films.txt"
echo "    $n media files copied"

echo "==> Checking Cloudflare's 25 MiB per-file limit"
big=$(find assets -type f -size +25M || true)
if [ -n "$big" ]; then
  echo "Too large, re-encode before pushing:"; echo "$big"; exit 1
fi
echo "    all files within the limit"

git add -A
git commit -m "Add redesigned multi-page site"
echo
echo "==> Pushing. GitHub will ask for your username, then a personal"
echo "    access token in place of a password."
git push -u origin redesign-2026

cat <<'DONE'

Pushed to branch redesign-2026.

Preview URL: Cloudflare dashboard -> Workers & Pages ->
anavafilms-brand-design -> Deployments -> redesign-2026.

main is untouched, so anavafilms.com is unaffected.
DONE
